# Semana 09 — Primer requerimiento: ventana de ingreso (login)

Fragmento funcional aislado del proyecto **Pequeños Exploradores LMS**, adaptado a un proyecto Vite + React + TypeScript.

## Ejecución

```bash
npm install
npm run dev
```

## Pruebas de demostración

- Familiar: usuario `familia`, contraseña `admin`.
- Institucional administrativo: `admin` / `admin`.
- Institucional docente: `docente` / `admin`.
- Institucional apoderado: `padre` / `admin`.

**Aviso:** estos datos son ficticios. El login comprueba cuentas en memoria, sin API, base de datos ni sesiones seguras. No utilizar como autenticación real ni introducir información personal.
