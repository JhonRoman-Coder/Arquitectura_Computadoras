import { FormEvent, useState } from 'react';
import './style.css';

type Role = 'admin' | 'docente' | 'padre';
type Space = 'familiar' | 'institucional';
type User = { username: string; password: string; role: Role; space: Space; name: string; status: 'activo' | 'pendiente' };

// Datos ficticios extraídos conceptualmente del prototipo Pequeños Exploradores LMS.
// SOLO DEMOSTRACIÓN: la autenticación real requiere backend y contraseñas cifradas.
const users: User[] = [
  { username: 'admin', password: 'admin', role: 'admin', space: 'institucional', name: 'Dirección de demostración', status: 'activo' },
  { username: 'docente', password: 'admin', role: 'docente', space: 'institucional', name: 'María Flores', status: 'activo' },
  { username: 'padre', password: 'admin', role: 'padre', space: 'institucional', name: 'Ana Torres', status: 'activo' },
  { username: 'familia', password: 'admin', role: 'padre', space: 'familiar', name: 'Familia Exploradora', status: 'activo' },
];

export default function App() {
  const [space, setSpace] = useState<Space>('familiar');
  const [role, setRole] = useState<Role>('padre');
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [currentUser, setCurrentUser] = useState<User | null>(null);

  const chooseSpace = (next: Space) => {
    setSpace(next); setRole(next === 'familiar' ? 'padre' : 'docente');
    setUsername(''); setPassword(''); setError(''); setCurrentUser(null);
  };

  const login = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const found = users.find(u =>
      u.username.trim().toLowerCase() === username.trim().toLowerCase() &&
      u.password === password && u.role === role &&
      u.space === space && u.status === 'activo'
    );
    if (!found) { setError('Credenciales incorrectas, rol distinto o cuenta pendiente.'); return; }
    setError(''); setCurrentUser(found);
  };

  if (currentUser) return <main className="card dashboard">
    <h1>¡Bienvenido, {currentUser.name}!</h1>
    <p>Espacio: {currentUser.space} · Perfil: {currentUser.role}</p>
    <button onClick={() => { setCurrentUser(null); setPassword(''); }}>Cerrar sesión</button>
  </main>;

  return <main className="layout">
    <section className="hero"><span>PEQUEÑOS EXPLORADORES LMS</span><h1>¡Creciendo juntos!</h1>
      <p>Experiencias educativas y seguimiento del aprendizaje para la primera infancia.</p>
      <div className="feature">✨ Experiencias personalizadas</div>
      <div className="feature">⭐ Seguimiento del aprendizaje</div>
      <div className="feature">🛡️ Acceso infantil supervisado</div>
    </section>
    <section className="card">
      <p className="eyebrow">ACCESO DE DEMOSTRACIÓN</p><h2>Iniciar sesión</h2>
      <div className="tabs" aria-label="Modalidad de acceso">
        <button className={space === 'familiar' ? 'selected' : ''} onClick={() => chooseSpace('familiar')}>Familiar</button>
        <button className={space === 'institucional' ? 'selected' : ''} onClick={() => chooseSpace('institucional')}>Institucional</button>
      </div>
      {space === 'institucional' && <label>Perfil
        <select value={role} onChange={e => { setRole(e.target.value as Role); setError(''); }}>
          <option value="admin">Administrativo</option><option value="docente">Docente</option><option value="padre">Apoderado</option>
        </select></label>}
      <form onSubmit={login}>
        <label>Usuario<input autoComplete="username" required value={username} onChange={e => setUsername(e.target.value)} placeholder="Ingresa tu usuario" /></label>
        <label>Contraseña<input autoComplete="current-password" type="password" required value={password} onChange={e => setPassword(e.target.value)} placeholder="Ingresa tu contraseña" /></label>
        {error && <p role="alert" className="error">{error}</p>}
        <button className="submit" type="submit">Ingresar a mi espacio</button>
      </form>
      <p className="hint">Prueba: {space === 'familiar' ? 'familia' : role} / admin</p>
    </section>
  </main>;
}
